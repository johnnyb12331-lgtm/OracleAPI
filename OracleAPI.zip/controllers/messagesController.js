const db = require('../config/db');

// ✅ Send Message
const sendMessage = (req, res) => {
  const { sender_id, receiver_id, message_text } = req.body;
  const sentAt = new Date();

  db.query(
    'INSERT INTO messages (sender_id, receiver_id, message_text, sent_at) VALUES (?, ?, ?, ?)',
    [sender_id, receiver_id, message_text, sentAt],
    (err, results) => {
      if (err) return res.status(500).send({ error: 'Database error' });
      res.status(201).send({ message: 'Message sent successfully', messageId: results.insertId });
    }
  );
};

// ✅ Mark as Delivered
const markAsDelivered = (req, res) => {
  const { id } = req.params;
  const deliveredAt = new Date();

  db.query(
    'UPDATE messages SET is_delivered = 1, delivered_at = ? WHERE id = ?',
    [deliveredAt, id],
    (err, result) => {
      if (err) return res.status(500).send({ error: 'Database error' });
      res.send({ message: 'Message marked as delivered' });
    }
  );
};

// ✅ Mark as Read
const markAsRead = (req, res) => {
  const { id } = req.params;
  const readAt = new Date();

  db.query(
    'UPDATE messages SET is_read = 1, read_at = ? WHERE id = ?',
    [readAt, id],
    (err, result) => {
      if (err) return res.status(500).send({ error: 'Database error' });
      res.send({ message: 'Message marked as read' });
    }
  );
};

// ✅ Get Messages Between Two Users
const getMessages = (req, res) => {
  const { user1, user2 } = req.query;

  db.query(
    `SELECT * FROM messages
     WHERE (
       (sender_id = ? AND receiver_id = ? AND is_deleted_by_sender = 0)
       OR
       (sender_id = ? AND receiver_id = ? AND is_deleted_by_receiver = 0)
     )
     ORDER BY sent_at ASC`,
    [user1, user2, user2, user1],
    (err, results) => {
      if (err) return res.status(500).send({ error: 'Database error' });
      res.send(results);
    }
  );
};

const getAllMessages = (req, res) => {
 const user_id = req.query.user_id || req.body.user_id;

  db.query(
    `SELECT * FROM messages
     WHERE
       (sender_id = ? AND is_deleted_by_sender = 0)
       OR
       (receiver_id = ? AND is_deleted_by_receiver = 0)
     ORDER BY sent_at DESC`,
    [user_id, user_id],
    (err, results) => {
      if (err) return res.status(500).send({ error: 'Database error' });
      res.send(results);
    }
  );
};

// ✅ Get chat users for a user (chat list, like WhatsApp)
const getChatList = (req, res) => {
  const { user_id } = req.query;

  db.query(
    `
    SELECT 
      IF(sender_id = ?, receiver_id, sender_id) AS user_id,
      MAX(sent_at) AS last_message_time
    FROM messages
    WHERE 
      (sender_id = ? AND is_deleted_by_sender = 0)
      OR
      (receiver_id = ? AND is_deleted_by_receiver = 0)
    GROUP BY user_id
    ORDER BY last_message_time DESC
    `,
    [user_id, user_id, user_id],
    (err, results) => {
      if (err) return res.status(500).send({ error: 'Database error' });
      res.send(results);
    }
  );
};


// ✅ Delete Message (Soft Delete)
const deleteMessage = (req, res) => {
  const { id } = req.params;
  const { user_id } = req.body;

  db.query('SELECT sender_id, receiver_id FROM messages WHERE id = ?', [id], (err, results) => {
    if (err || results.length === 0) return res.status(404).send({ error: 'Message not found' });

    const msg = results[0];
    const field = user_id == msg.sender_id
      ? 'is_deleted_by_sender'
      : user_id == msg.receiver_id
        ? 'is_deleted_by_receiver'
        : null;

    if (!field) return res.status(403).send({ error: 'Not authorized to delete this message' });

    db.query(`UPDATE messages SET ${field} = 1 WHERE id = ?`, [id], (err) => {
      if (err) return res.status(500).send({ error: 'Database error' });
      res.send({ message: 'Message deleted successfully' });
    });
  });
};

module.exports = {
  sendMessage,
  markAsDelivered,
  markAsRead,
  getMessages,
  deleteMessage,
  getAllMessages,
  getChatList
};
