const { OAuth2Client } = require('google-auth-library');
const fetch = require('node-fetch');
const db = require('../config/db');
const authguard = require('../utils/guardtoken');

// جميع Client IDs المسموح بها (Web - Android - iOS)
const GOOGLE_CLIENT_IDS = [
  '694209900973-6lo66hjioqq20sk0ildk62n70527r95k.apps.googleusercontent.com',
  '694209900973-rd4mp9pn58kst8jh3qs988o8aencorh9.apps.googleusercontent.com',
  'YOUR_IOS_CLIENT_ID.apps.googleusercontent.com',
];

const client = new OAuth2Client();

const googleLogin = async (req, res) => {
  const { accessToken, idToken } = req.body;

  if (!accessToken && !idToken)
    return res.status(400).json({ status: 'error', message: 'accessToken or idToken required' });

  try {
    let payload;

    if (idToken) {
      // ✅ تحقق من id_token (لـ Android/iOS)
      const ticket = await client.verifyIdToken({
        idToken,
        audience: GOOGLE_CLIENT_IDS,
      });
      payload = ticket.getPayload();
    } else {
      // ✅ استخدام access_token (لـ Web)
      const response = await fetch(`https://www.googleapis.com/oauth2/v1/userinfo?access_token=${accessToken}`);
      payload = await response.json();

      if (payload.error) {
        return res.status(401).json({ status: 'error', message: 'Invalid Google Token' });
      }
    }

    const userid = payload.sub || payload.id;
    const email = payload.email;
    const name = payload.name;
    const avatar = payload.picture || null;

    // 🔁 تحقق أو أنشئ المستخدم
    db.query('SELECT * FROM users WHERE social_id = ? AND provider = ?', [userid, 'google'], (err, results) => {
      if (err) return res.status(500).json({ status: 'error', message: 'خطأ في قاعدة البيانات' });

      if (results.length === 0) {
        db.query(
          'INSERT INTO users (social_id, provider, email) VALUES (?, ?, ?)',
          [userid, 'google', email],
          (err, insertResult) => {
            if (err) return res.status(500).json({ status: 'error', message: 'User creation error' });
            const newUserId = insertResult.insertId;
            sendTokens(newUserId, res, false, { name, email, avatar });
          }
        );
      } else {
        const internalUserId = results[0].id;
        db.query(
  `SELECT u.email, ud.isProfileComplete, ud.name, ud.dateOfBirth, ud.gender, ud.avatar 
   FROM usersdata ud
   JOIN users u ON ud.userId = u.id
   WHERE ud.userId = ?`,
  [internalUserId],
  (err, profileResults) => {
    if (err) return res.status(500).json({ status: 'error', message: 'Failed to fetch profile data' });

    if (profileResults.length === 0) {
      // لا توجد بيانات في usersdata، أرسل بيانات جوجل مباشرة
      sendTokens(internalUserId, res, false, { name, email, avatar });
    } else {
      const profile = profileResults[0];

      // إذا كان الإيميل فارغ (نادر الحدوث)، استخدم إيميل جوجل كاحتياط
      if (!profile.email || profile.email.trim() === '') {
        profile.email = email;
      }

      sendTokens(internalUserId, res, !!profile.isProfileComplete, profile);
    }
  }
);

      }
    });
  } catch (error) {
    console.error('Google login error: - socialController.js:90', error);
    return res.status(401).json({ status: 'error', message: 'Google token verification failed' });
  }
};

function sendTokens(userId, res, isProfileComplete, profileData) {
  const accessToken = authguard.generateAccessToken(userId);
  const refreshToken = authguard.generateRefreshToken(userId);

  return res.json({
    status: 'success',
    message: 'logged in successfully.',
    accessToken,
    refreshToken,
    expiryDate: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
    isProfileComplete,
    userId,  // <-- أضف هذا السطر لإرسال userId
    userProfile: {
      name: profileData.name || '',
      email: profileData.email || '',
      dateOfBirth: profileData.dateOfBirth || null,
      gender: profileData.gender || '',
      avatar: profileData.avatar || null,
    },
  });
}


module.exports = {
  googleLogin,
};
