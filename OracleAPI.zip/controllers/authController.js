const db = require('../config/db');
const bcrypt = require('bcrypt');
const authguard = require('../utils/guardtoken');
const jwt = require('jsonwebtoken');

const Login = async (req, res) => {
  const { email, password } = req.body;

  console.log(`[Login] Attempt for email: ${email} - authController.js:9`);

  const checkQury = 'SELECT * FROM users WHERE email = ?';
  const checktokenQuery = 'SELECT * FROM refresh_tokens WHERE user_id = ?';
  const deleteOldTokensQuery = 'DELETE FROM refresh_tokens WHERE user_id = ?';
  const insertNewTokenQuery = 'INSERT INTO refresh_tokens (token, user_id, expires_at) VALUES (?, ?, ?)';
  const checkProfileQuery = 'SELECT * FROM usersdata WHERE userId = ?';

  db.query(checkQury, [email], async (err, results) => {
    if (err) {
      console.error('[Login] Database error: - authController.js:19', err);
      return res.status(500).json({ status: 'error', message: 'Database error' });
    }

    if (results.length === 0) {
      console.warn('[Login] Invalid email or password for: - authController.js:24', email);
      return res.status(401).json({ status: 'error', message: 'Invalid email or password' });
    }

    const user = results[0];
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      console.warn('[Login] Password mismatch for: - authController.js:32', email);
      return res.status(401).json({ status: 'error', message: 'Invalid email or password' });
    }

    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + authguard.REFRESH_TOKEN_LIFETIME_DAYS);

    const accessToken = authguard.generateAccessToken(user.id);
    const refreshToken = authguard.generateRefreshToken(user.id);

    db.query(checktokenQuery, [user.id], (err, tokenResults) => {
      if (err) {
        console.error('[Login] Token DB check error: - authController.js:44', err);
        return res.status(500).json({ status: 'error', message: 'Database error' });
      }

      const insertToken = () => {
        db.query(insertNewTokenQuery, [refreshToken, user.id, expiryDate], (err) => {
          if (err) {
            console.error('[Login] Insert token error: - authController.js:51', err);
            return res.status(500).json({ status: 'error', message: 'Database error' });
          }

          // ✅ تحقق من وجود بيانات الملف الشخصي
          db.query(checkProfileQuery, [user.id], (err, profileResults) => {
            if (err) {
              console.error('[Login] Profile check error: - authController.js:58', err);
              return res.status(500).json({ status: 'error', message: 'Database error' });
            }

            const isProfileComplete = profileResults.length > 0;

            console.log(`[Login] Login successful for user: ${user.email}, Profile Complete: ${isProfileComplete} - authController.js:64`);
            res.status(200).json({
              status: 'success',
              message: 'Login successful',
              accessToken,
              refreshToken,
              expiryDate: expiryDate.toISOString(),
              isProfileComplete,
              userId: user.id
            });
          });
        });
      };

      if (tokenResults.length > 0) {
        db.query(deleteOldTokensQuery, [user.id], (err) => {
          if (err) {
            console.error('[Login] Delete old tokens error: - authController.js:81', err);
            return res.status(500).json({ status: 'error', message: 'Database error' });
          }
          insertToken();
        });
      } else {
        insertToken();
      }
    });
  });
};


const Register = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !email.trim()) {
    return res.status(400).json({ status: 'error', message: 'Email is required and cannot be empty' });
  }
  if (!password || !password.trim()) {
    return res.status(400).json({ status: 'error', message: 'Password is required and cannot be empty' });
  }

  const saltRounds = 10;
  const hashedPassword = await bcrypt.hash(password, saltRounds);

  const checkUserQuery = 'SELECT * FROM users WHERE email = ?';
  const insertQuery = 'INSERT INTO users (email, password, created_at) VALUES (?, ?, ?)';
  const createdAt = new Date();

  db.query(checkUserQuery, [email], (err, results) => {
    if (err) {
      return res.status(500).json({ status: 'error', message: 'Database error' });
    }

    if (results.length > 0) {
      return res.status(400).json({ status: 'error', message: 'Email already exists' });
    }

    db.query(insertQuery, [email, hashedPassword, createdAt], (err, results) => {
      if (err) {
        return res.status(500).json({ status: 'error', message: 'Database error' });
      }
      res.status(201).json({
        status: 'success',
        message: 'User registered successfully',
        userId: results.insertId,
      });
    });
  });
};



const Logout = (req, res) => {
  const { refreshToken } = req.body;

  if (!refreshToken) {
    return res.status(400).json({ error: "Refresh token is required" });
  }

  jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET, (err, decoded) => {
    if (err || !decoded?.userId) {
      return res.status(401).json({ error: "Invalid or expired refresh token" });
    }

    const userId = decoded.userId;

    // التحقق من أن التوكن يخص نفس المستخدم
    const query = `
      DELETE FROM refresh_tokens 
      WHERE token = ? AND user_id = ?
    `;
    db.query(query, [refreshToken, userId], (err, result) => {
      if (err) {
        return res.status(500).json({ error: "Database error" });
      }

      if (result.affectedRows === 0) {
        return res.status(404).json({ error: "Refresh token not found or already deleted" });
      }

      return res.status(200).json({ message: "Logout successful" });
    });
  });
};


const RefreshToken = (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ message: 'Refresh token required' });

  jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET, (err, decoded) => {
    if (err) return res.status(403).json({ message: 'Invalid refresh token' });

    const userId = decoded.userId;

    // إنشاء توكن جديد
    const newAccessToken = jwt.sign({ userId }, process.env.ACCESS_TOKEN_SECRET, {
      expiresIn: process.env.ACCESS_TOKEN_LIFETIME,
    });

    // (اختياري) إنشاء refresh token جديد
    const newRefreshToken = jwt.sign({ userId }, process.env.REFRESH_TOKEN_SECRET, {
      expiresIn: process.env.REFRESH_TOKEN_LIFETIME,
    });

     const expiresInMs = authguard.parseDurationToMs(process.env.ACCESS_TOKEN_LIFETIME);
    const expiryDate = new Date(Date.now() + expiresInMs).toISOString();

    res.json({
      accessToken: newAccessToken,
      refreshToken: newRefreshToken, // أرسل توكن جديد إن قمت بإنشائه
      expiryDate,
    });

  });
};

//expiryDate: new Date(Date.now() + expiryDate),



module.exports = {
  Login,
  Register,
    Logout,
    RefreshToken
};