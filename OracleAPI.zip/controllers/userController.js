const db = require('../config/db');


const getProfile = (req, res) => {
  const userId = req.params.userId; // ← استخدم userId من الرابط

  const query = `
    SELECT u.email, ud.name, ud.dateOfBirth, ud.gender, ud.avatar, ud.bio
    FROM users u
    LEFT JOIN usersdata ud ON u.id = ud.userId
    WHERE u.id = ?
  `;

  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('[getProfile] Database error: - userController.js:16', err);
      return res.status(500).json({ status: 'error', message: 'Database error' });
    }

    if (results.length === 0) {
      return res.status(404).json({ status: 'error', message: 'User profile not found' });
    }

    const profile = results[0];

    res.json({
      status: 'success',
      email: profile.email || '',
      name: profile.name || '',
      dateOfBirth: profile.dateOfBirth || '',
      gender: profile.gender || '',
      avatar: profile.avatar || '',
      bio: profile.bio || '',
    });
  });
};


const getUserMe = (req, res) => {
  const userId = req.userId;

  const query = `
    SELECT u.email, ud.isProfileComplete, ud.name, ud.dateOfBirth, ud.gender, ud.avatar 
    FROM users u 
    LEFT JOIN usersdata ud ON u.id = ud.userId
    WHERE u.id = ?
  `;

  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('[getUserMe] Database error: - userController.js:51', err);
      return res.status(500).json({ status: 'error', message: 'Database error' });
    }

    if (results.length === 0) {
      return res.status(404).json({ status: 'error', message: 'المستخدم غير موجود' });
    }

    const userData = results[0];
    res.status(200).json({
      status: 'success',
      userProfile: {
        email: userData.email,
        name: userData.name,
        dateOfBirth: userData.dateOfBirth,
        gender: userData.gender,
        avatar: userData.avatar,
        isProfileComplete: !!userData.isProfileComplete,
      }
    });
  });
};

const getFollowerCount = (req, res) => {
  const userId = req.params.userId;

  const query = `
    SELECT COUNT(*) AS followerCount 
    FROM followers 
    WHERE following_user_id = ?
  `;

  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('[getFollowerCount] Database error: - userController.js:85', err);
      return res.status(500).json({ status: 'error', message: 'Database error' });
    }

    if (results.length === 0) {
      return res.status(404).json({ status: 'error', message: 'المستخدم غير موجود' });
    }

    res.status(200).json({
      status: 'success',
      followerCount: results[0].followerCount
    });
  });
};

const getFollowingCount = (req, res) => {
  const userId = req.params.userId;
  const query = `
    SELECT COUNT(*) AS followingCount 
    FROM followers 
    WHERE follower_user_id = ?
  `;
  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('[getFollowingCount] Database error: - userController.js:109', err);
      return res.status(500).json({ status: 'error', message: 'Database error' });
    }

    if (results.length === 0) {
      return res.status(404).json({ status: 'error', message: 'المستخدم غير موجود' });
    }

    res.status(200).json({
      status: 'success',
      followingCount: results[0].followingCount
    });
  });
}

const getLikesCount = (req, res) => {
  const userId = req.params.userId;
  const query = `
    SELECT COUNT(*) AS likesCount 
    FROM likes 
    WHERE userId = ?
  `;
  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('[getLikesCount] Database error: - userController.js:133', err);
      return res.status(500).json({ status: 'error', message: 'Database error' });
    }

    if (results.length === 0) {
      return res.status(404).json({ status: 'error', message: 'المستخدم غير موجود' });
    }

    res.status(200).json({
      status: 'success',
      likesCount: results[0].likesCount
    });
  });
};  

module.exports = { 
  getUserMe,
  getFollowerCount,
  getFollowingCount,
  getLikesCount,
  getProfile
 };
