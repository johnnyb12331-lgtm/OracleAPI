const db = require('../config/db');

const setupProfile = (req, res) => {
  const userId = req.userId;
  const { name, dateOfBirth, gender, avatar } = req.body;

  if (!name || !dateOfBirth || !gender) {
    return res.status(400).json({ status: 'error', message: 'الاسم، العمر والجنس مطلوبة' });
  }

  // أولاً تحقق هل يوجد سجل لهذا المستخدم في usersdata
  db.query('SELECT * FROM usersdata WHERE userId = ?', [userId], (err, results) => {
    if (err) {
      console.error('[setupProfile] DB error on SELECT:', err);
      return res.status(500).json({ status: 'error', message: 'Database error' });
    }

    if (results.length > 0) {
      // يوجد سجل: قم بالتحديث
      const query = `
        UPDATE usersdata 
        SET name = ?, dateOfBirth = ?, gender = ?, avatar = ?, isProfileComplete = true 
        WHERE userId = ?
      `;
      db.query(query, [name, dateOfBirth, gender, avatar || null, userId], (err) => {
        if (err) {
          console.error('[setupProfile] DB error on UPDATE:', err);
          return res.status(500).json({ status: 'error', message: 'Database error' });
        }

        res.status(200).json({ status: 'success', message: 'تم تحديث الملف الشخصي بنجاح' });
      });

    } else {
      // لا يوجد سجل: قم بالإدراج
      const insertQuery = `
        INSERT INTO usersdata (userId, name, dateOfBirth, gender, avatar, isProfileComplete)
        VALUES (?, ?, ?, ?, ?, true)
      `;
      db.query(insertQuery, [userId, name, dateOfBirth, gender, avatar || null], (err) => {
        if (err) {
          console.error('[setupProfile] DB error on INSERT:', err);
          return res.status(500).json({ status: 'error', message: 'Database error' });
        }

        res.status(200).json({ status: 'success', message: 'تم إنشاء الملف الشخصي بنجاح' });
      });
    }
  });
};

module.exports = {
  setupProfile,
};
