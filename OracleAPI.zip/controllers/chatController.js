const db = require('../config/db');

// إرسال رسالة
const sendMessage = async (req, res) => {
  const { sender_id, receiver_id, text, type, media_url } = req.body;

  if (!sender_id || !receiver_id || !type) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
    const [result] = await db.query(`
      INSERT INTO messages (sender_id, receiver_id, text, type, media_url)
      VALUES (?, ?, ?, ?, ?)
    `, [sender_id, receiver_id, text, type, media_url]);

    res.status(201).json({ message: 'Message sent', id: result.insertId });
  } catch (error) {
    console.error('Send Message Error: - chatController.js:19', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// جلب الرسائل بين مستخدمين
const getMessages = async (req, res) => {
  const { user1, user2 } = req.query;

  if (!user1 || !user2) {
    return res.status(400).json({ error: 'Missing user ids' });
  }

  try {
    const [messages] = await db.query(`
      SELECT * FROM messages 
      WHERE 
        (sender_id = ? AND receiver_id = ?) OR 
        (sender_id = ? AND receiver_id = ?)
      ORDER BY time DESC
    `, [user1, user2, user2, user1]);

    res.json(messages);
  } catch (error) {
    console.error('Get Messages Error: - chatController.js:43', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

const getInbox = (req, res) => {
 const userId = req.user?.userId;

    console.log('req.user: - chatController.js:51', req.user);

  if (!userId) {
    return res.status(400).json({ error: 'User ID missing from token' });
  }

  console.log("Fetching inbox for userId: - chatController.js:57", userId);

  const query = `
    SELECT 
      u.userId AS id,
      u.name,
      u.avatar,
      u.gender,
      m.text AS lastMessage,
      MAX(m.time) AS lastTime,
      SUM(CASE WHEN m.receiver_id = ? AND m.status = 'sent' THEN 1 ELSE 0 END) AS unreadCount
    FROM messages m
    JOIN usersdata u ON 
      (u.userId = IF(m.sender_id = ?, m.receiver_id, m.sender_id))
    WHERE m.sender_id = ? OR m.receiver_id = ?
    GROUP BY u.userId
    ORDER BY lastTime DESC
  `;

  db.query(query, [userId, userId, userId, userId], (err, results) => {
    if (err) {
      console.error('Error getting inbox: - chatController.js:78', err);
      return res.status(500).json({ error: 'Internal server error' });
    }

    res.json(results);
  });
};


const getmessage = (req, res) => {
  const { user1, user2 } = req.query; // تمرير IDs بدل chatId
  const page = parseInt(req.query.page) || 0;
  const limit = parseInt(req.query.limit) || 10;
  const offset = page * limit;

  if (!user1 || !user2) {
    return res.status(400).json({ error: 'Missing user ids' });
  }

  const query = `
    SELECT * FROM messages 
    WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
    ORDER BY time DESC 
    LIMIT ? OFFSET ?
  `;

  db.query(query, [user1, user2, user2, user1, limit, offset], (err, rows) => {
    if (err) {
      console.error('Error fetching chat messages:', err);
      return res.status(500).json({ error: 'Internal server error' });
    }
    res.json(rows);
  });
  console.log('getmessage called with user1:', user1, 'user2:', user2, 'page:', page, 'limit:', limit);
};


const getmessageDD = (req, res) => {
  const { chatId } = req.params;
  const page = parseInt(req.query.page) || 0;
  const limit = parseInt(req.query.limit) || 10;
  const offset = page * limit;

  const query = `
    SELECT * FROM messages 
    WHERE chat_id = ? 
    ORDER BY time DESC 
    LIMIT ? OFFSET ?
  `;

  db.query(query, [chatId, limit, offset], (err, rows) => {
    if (err) {
      console.error('Error fetching chat messages:', err);
      return res.status(500).json({ error: 'Internal server error' });
    }

    res.json(rows);
  });
};



module.exports = {
  sendMessage,
  getMessages,
  getInbox,
  getmessage
};