const jwt = require('jsonwebtoken');

const authguard = (req, res, next) => {
  console.log('authguard triggered - authguard.js:4');
  
  const authHeader = req.headers['authorization'];
  if (!authHeader) return res.status(401).json({ message: 'مطلوب التوثيق' });

  const token = authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'مطلوب التوثيق' });

  console.log('Token to verify: - authguard.js:12', token);
  jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, decoded) => {
    if (err) return res.status(403).json({ message: 'توكن غير صالح أو منتهي' });

    console.log('Decoded token: - authguard.js:16', decoded);
    req.user = { userId: decoded.userId || decoded.id };
    console.log('Set req.user: - authguard.js:18', req.user);
    next();
  });
};

module.exports = authguard;
