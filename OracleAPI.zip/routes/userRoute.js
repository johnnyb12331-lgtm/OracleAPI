const express = require('express');
const router = express.Router();
const authguard = require('../guard/authguard');
const  usersdata  = require('../controllers/userController');

//router.get('/me', authguard, usersdata.getUserMe);
router.get('/:userId/profile',  usersdata.getProfile);

router.get('/:userId/followers/count', authguard, usersdata.getFollowerCount);
router.get('/:userId/following/count', authguard, usersdata.getFollowingCount);
router.get('/:userId/likes/count', authguard, usersdata.getLikesCount);


module.exports = router;
