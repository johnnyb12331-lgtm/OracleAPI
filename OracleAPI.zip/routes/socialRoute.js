const express = require('express');
const router = express.Router();
const socialcontroller = require('../controllers/socialController');

router.post('/GoogleLogin', socialcontroller.googleLogin);


module.exports = router;
