
const express = require('express');
const router = express.Router();
const chatController = require('../controllers/chatController');
const authguard = require('../guard/authguard');
// إرسال رسالة
router.post('/send', chatController.sendMessage);

// جلب رسائل بين مستخدمين
router.get('/history', chatController.getMessages);

// جلب صندوق الوارد
router.get('/getInbox', authguard,  chatController.getInbox);

// جلب رسائل محادثة معينة
router.get('/messages', chatController.getmessage);

module.exports = router;
