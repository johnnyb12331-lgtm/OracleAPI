const express = require('express');
const app = express();
const cors = require('cors');
const server = require('http').Server(app);; 
const io = require('socket.io')(server);
require('dotenv').config();

const port = 3000;
const customIP = '192.168.1.177'

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/uploads', express.static('uploads'));

const authRoutes = require('./routes/authRoute');
const socialRoutes = require('./routes/socialRoute');
app.use('/api/auth/social', socialRoutes);
app.use('/api/auth', authRoutes);

const setupProfileRoutes = require('./routes/setupprofileRoute');
app.use('/api/user', setupProfileRoutes);

const userRoutes = require('./routes/userRoute');
app.use('/api/user', userRoutes);

const messageRoutes = require('./routes/messagesRoute');
app.use('/api', messageRoutes);


const chatRoutes = require('./routes/chatRoute');
app.use('/api/chat', chatRoutes);




const connectedUsers = {};

io.on('connection', (socket) => {
  console.log('🟢 User connected: - server.js:41', socket.id);

  // المستخدم يعرّف نفسه
  socket.on('join', (userId) => {
    connectedUsers[userId] = socket.id;
    console.log(`User ${userId} joined with socket ${socket.id} - server.js:46`);
  });

  // إرسال رسالة
socket.on('send_message', async (message) => {
  // ابعت الرسالة للـ Queue بدل الحفظ مباشر
  await redis.lpush('chat_queue', JSON.stringify(message));

  // لو المستقبل متصل، ابعتهله فوراً
  const receiverSocket = connectedUsers[message.receiverId];
  if (receiverSocket) {
    io.to(receiverSocket).emit('receive_message', message);
  }
});


  // تأكيد القراءة
  socket.on('message_read', ({ messageId, receiverId }) => {
    const receiverSocket = connectedUsers[receiverId];
    if (receiverSocket) {
      io.to(receiverSocket).emit('message_read_ack', messageId);
    }
  });

  // عند فصل الاتصال
  socket.on('disconnect', () => {
    for (const userId in connectedUsers) {
      if (connectedUsers[userId] === socket.id) {
        delete connectedUsers[userId];
        console.log(`🔴 User ${userId} disconnected - server.js:70`);
        break;
      }
    }
  });
});







server.listen(port, customIP, () => {
  console.log(`Server is running on http://${customIP}:${port} - server.js:84`);
});

/*server.listen(port, () => {
  console.log(`Server is running on ${port}`);
});*/