const validation = require('../utils/authValidator');

module.exports = (req, res, next) => {
    if (req.path === '/Login') {
        // تحقق من بيانات تسجيل الدخول
        const loginValidation = validation.validateLogin(req.body);
        if (!loginValidation.valid) {
            return res.status(400).json({ message: loginValidation.message });
        } else {
            req.valid = true;
            next(); // استدعاء الميدل وير التالي
        }
    } else if (req.path === '/Register') {
        // تحقق من بيانات التسجيل
        const registerValidation = validation.validateRegister(req.body);
        if (!registerValidation.valid) {
            return res.status(400).json({ message: registerValidation.message });
        } else {
            req.valid = true;
            next(); // استدعاء الميدل وير التالي
        }
    } else {
        next(); // استدعاء الميدل وير التالي للمسارات الأخرى (مثل Logout, RefreshToken)
    }
};
