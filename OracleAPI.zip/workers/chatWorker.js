const Redis = require('ioredis');
const redis = new Redis();
const redisPublisher = new Redis();

io.on('connection', (socket) => {
  socket.on('join', (userId) => {
    connectedUsers[userId] = socket.id;
  });

  socket.on('send_message', async (message) => {
    // خزّن الرسالة في Queue
    await redis.lpush('chat_queue', JSON.stringify(message));

    // إذا المستقبل متصل، أبعت له مباشرة
    const receiverSocket = connectedUsers[message.receiverId];
    if (receiverSocket) {
      io.to(receiverSocket).emit('receive_message', message);
    }
  });
});

// Worker لمعالجة الرسائل من Queue
async function processQueue() {
  while (true) {
    const msgStr = await redis.brpop('chat_queue', 0); // blocking pop
    const message = JSON.parse(msgStr[1]);
    await saveMessageToDB(message); // حفظ في DB
  }
}
processQueue();
