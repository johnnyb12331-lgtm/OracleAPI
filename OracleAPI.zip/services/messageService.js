const db = require('../config/db');

async function saveMessageToDB(message) {
  const { sender_id, receiver_id, text, type, media_url } = message;
  const query = `
    INSERT INTO messages (sender_id, receiver_id, text, type, media_url)
    VALUES (?, ?, ?, ?, ?)
  `;
  await db.query(query, [sender_id, receiver_id, text, type, media_url]);
}

module.exports = { saveMessageToDB };
